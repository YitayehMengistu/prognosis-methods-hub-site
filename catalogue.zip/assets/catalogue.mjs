import {
  effectiveStatus, facets, prepareRecords, readState, selectRecords, tagsFor, writeState,
} from "./catalogue-filters.mjs";

const size = 20;
const query = document.querySelector("#catalogue-search");
const order = document.querySelector("#catalogue-order");
const statusLine = document.querySelector("#catalogue-status");
const sidebar = document.querySelector("#catalogue-facets");
const results = document.querySelector("#catalogue-results");
const pagination = document.querySelector("#catalogue-pagination");
const previous = document.querySelector("#catalogue-previous");
const next = document.querySelector("#catalogue-next");
const toggles = Object.fromEntries(["current", "open", "core"].map((key) => [
  key, document.querySelector(`#filter-${key}`),
]));
const noticeLabels = {
  correction: "Correction",
  erratum: "Erratum",
  expression_of_concern: "Expression of concern",
  retraction: "Retraction",
};

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function link(label, href) {
  const node = element("a", label);
  node.href = href;
  return node;
}

function publicLink(label, href) {
  if (!href) return null;
  try {
    const url = new URL(href);
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) return null;
    return link(label, url.href);
  } catch {
    return null;
  }
}

function doiUrl(doi) {
  return doi ? `https://doi.org/${encodeURIComponent(doi).replaceAll("%2F", "/")}` : null;
}

function pubmedUrl(pmid) {
  return pmid ? `https://pubmed.ncbi.nlm.nih.gov/${pmid}/` : null;
}

function detailBody(record, byId) {
  const { curated, harvested, identifiers } = record;
  const body = element("div", undefined, "record-details");
  if (effectiveStatus(record) === "retracted") {
    body.append(element("p", "This publication has a retraction notice.", "record-warning"));
  }
  const concerns = harvested.update_notices.some((notice) => notice.type === "expression_of_concern");
  if (concerns) body.append(element("p", "An expression of concern has been recorded.", "record-warning"));
  if (curated.superseded_by) {
    const successor = byId.get(curated.superseded_by);
    const paragraph = element("p", "Superseded by ", "successor");
    paragraph.append(link(successor.title, `resources.html#record-${successor.record.id}`));
    body.append(paragraph);
  }
  const guidance = element("dl");
  guidance.append(
    element("dt", "Use when"), element("dd", curated.use_when),
    element("dt", "Why it matters"), element("dd", curated.why_it_matters),
  );
  body.append(guidance);
  if (curated.key_points.length) {
    const points = element("ul", undefined, "record-points");
    points.append(...curated.key_points.map((point) => element("li", point)));
    body.append(points);
  }
  if (harvested.authors.length) body.append(element("p", harvested.authors.join(", "), "record-authors"));
  const metadata = [
    harvested.cited_by_count === null ? null : `${harvested.cited_by_count.toLocaleString()} citations`,
    harvested.software_latest_version ? `Version ${harvested.software_latest_version}` : null,
  ].filter(Boolean);
  if (metadata.length) body.append(element("p", metadata.join(" · "), "record-meta"));
  const links = [
    publicLink("DOI", doiUrl(identifiers.doi)),
    publicLink("PubMed", pubmedUrl(identifiers.pmid)),
    publicLink(curated.resource_type === "reporting_guideline" ? "Official guidance" : "Official resource",
      identifiers.urls.official),
    publicLink("Open-access copy", harvested.oa_url),
  ].filter(Boolean);
  if (links.length) {
    const group = element("div", undefined, "record-links");
    group.append(...links);
    body.append(group);
  }
  if (harvested.update_notices.length) {
    const notices = element("ul", undefined, "record-notices");
    for (const notice of harvested.update_notices) {
      const label = [noticeLabels[notice.type], notice.date].filter(Boolean).join(" · ");
      const item = element("li");
      item.append(publicLink(label, doiUrl(notice.doi) ?? pubmedUrl(notice.pmid)) ?? label);
      notices.append(item);
    }
    body.append(notices);
  }
  return body;
}

function resourceRow(entry, taxonomy, byId) {
  const { record, title } = entry;
  const { curated, harvested } = record;
  const visibleStatus = effectiveStatus(record);
  const row = element("tr");
  row.id = `record-${record.id}`;
  const citation = element("td", undefined, "record-citation");
  const details = element("details");
  const summary = element("summary");
  summary.append(element("span", title, "record-title"));
  const brief = [harvested.authors[0], harvested.venue].filter(Boolean).join(" · ");
  if (brief) summary.append(element("span", brief, "record-brief"));
  details.append(summary);
  details.addEventListener("toggle", () => {
    if (details.open && details.childElementCount === 1) details.append(detailBody(record, byId));
  });
  citation.append(details);
  const type = element("td", taxonomy.resource_type[curated.resource_type].label, "record-type");
  const year = element("td", harvested.year ?? "—", "record-year");
  const tier = element("td", undefined, "record-tier");
  const tierBadge = element("span", String(curated.authority_tier), "hub-badge");
  tierBadge.title = taxonomy.authority_tier[curated.authority_tier].label;
  tier.append(tierBadge);
  const flags = element("td", undefined, "record-flags");
  flags.append(element("span", taxonomy.status[visibleStatus].label, `hub-badge status-${visibleStatus}`));
  flags.append(element("span", taxonomy.access[curated.access].label, `hub-badge access-${curated.access}`));
  if (visibleStatus !== "corrected" && harvested.update_notices.some(({ type }) => (
    type === "correction" || type === "erratum"
  ))) flags.append(element("span", "Correction", "hub-badge"));
  if (harvested.update_notices.some(({ type }) => type === "expression_of_concern")) {
    flags.append(element("span", "Expression of concern", "hub-badge status-retracted"));
  }
  if (curated.core) flags.append(element("span", "Core", "hub-badge badge-core"));
  row.append(citation, type, year, tier, flags);
  return row;
}

function tableFor(entries, taxonomy, byId) {
  const table = element("table", undefined, "resource-table");
  const caption = element("caption", "Matching catalogue resources", "visually-hidden");
  const header = element("tr");
  for (const [title, css] of [
    ["Resource", "record-citation"], ["Type", "record-type"], ["Year", "record-year"],
    ["Tier", "record-tier"], ["Status", "record-flags"],
  ]) {
    const cell = element("th", title, css);
    cell.scope = "col";
    header.append(cell);
  }
  const body = element("tbody");
  body.append(...entries.map((entry) => resourceRow(entry, taxonomy, byId)));
  const head = element("thead");
  head.append(header);
  table.append(caption, head, body);
  return table;
}

function addFacets(taxonomy, prepared, state) {
  for (const [facet, label] of Object.entries(facets)) {
    const group = element("details", undefined, "facet-group");
    group.dataset.facet = facet;
    group.open = ["resource_type", "outcome_type"].includes(facet) || state.filters[facet].size > 0;
    group.append(element("summary", label));
    const choices = element("fieldset", undefined, "facet-choices");
    choices.append(element("legend", label, "visually-hidden"));
    for (const [value, definition] of Object.entries(taxonomy[facet])) {
      const labelEl = element("label");
      const box = element("input");
      box.type = "checkbox";
      box.name = facet;
      box.value = value;
      labelEl.append(box, element("span", definition.label));
      const count = prepared.filter(({ record }) => tagsFor(record, facet).includes(value)).length;
      labelEl.append(element("span", String(count), "facet-count"));
      choices.append(labelEl);
    }
    group.append(choices);
    sidebar.append(group);
  }
}

async function getJSON(relative) {
  const response = await fetch(new URL(relative, import.meta.url));
  if (!response.ok) throw new Error(`Catalogue source unavailable (HTTP ${response.status})`);
  return response.json();
}

async function start() {
  const [records, taxonomy] = await Promise.all([
    getJSON("../generated/records.json"), getJSON("../generated/taxonomy.json"),
  ]);
  const prepared = prepareRecords(records, taxonomy);
  const byId = new Map(prepared.map((entry) => [entry.record.id, entry]));
  const reset = document.querySelector("#catalogue-reset");
  let state = readState(new URLSearchParams(location.search), taxonomy);
  let page = 0;
  addFacets(taxonomy, prepared, state);
  const boxes = [...sidebar.querySelectorAll("input[type=checkbox]")];

  function updateControls() {
    query.value = state.query;
    order.value = state.order;
    for (const [key, input] of Object.entries(toggles)) input.checked = state[key];
    for (const box of boxes) {
      box.checked = state.filters[box.name].has(box.value);
      if (box.checked) box.closest("details").open = true;
    }
  }

  function render(focusId) {
    const matched = selectRecords(prepared, state);
    const pageCount = Math.ceil(matched.length / size);
    const position = focusId ? matched.findIndex(({ record }) => record.id === focusId) : -1;
    if (position >= 0) page = Math.floor(position / size);
    page = Math.min(page, Math.max(pageCount - 1, 0));
    const low = page * size;
    const entries = matched.slice(low, low + size);
    statusLine.textContent = matched.length
      ? `Showing ${low + 1}–${low + entries.length} of ${matched.length} resources`
      : "0 matching resources";
    results.replaceChildren(matched.length
      ? tableFor(entries, taxonomy, byId)
      : element("p", "Adjust the search or filters to find more resources.", "no-results"));
    pagination.hidden = pageCount < 2;
    previous.disabled = page === 0;
    next.disabled = page >= pageCount - 1;
    document.querySelector("#catalogue-page").textContent = `Page ${page + 1} of ${pageCount}`;
    if (position >= 0) {
      const row = document.getElementById(`record-${focusId}`);
      row.querySelector("details").open = true;
      row.querySelector("summary").focus({ preventScroll: true });
      row.scrollIntoView({ block: "start" });
    }
  }

  function applyFilters() {
    state.query = query.value;
    state.order = order.value;
    for (const [key, input] of Object.entries(toggles)) state[key] = input.checked;
    for (const box of boxes) {
      const selected = state.filters[box.name];
      if (box.checked) selected.add(box.value);
      else selected.delete(box.value);
    }
    const search = writeState(state).toString();
    history.replaceState(null, "", location.pathname + (search ? `?${search}` : ""));
    page = 0;
    render();
  }

  function readLocation() {
    state = readState(new URLSearchParams(location.search), taxonomy);
    updateControls();
    const match = /^#record-([a-z0-9-]+)$/u.exec(location.hash);
    render(match?.[1]);
  }

  query.addEventListener("input", applyFilters);
  order.addEventListener("change", applyFilters);
  for (const input of Object.values(toggles)) input.addEventListener("change", applyFilters);
  sidebar.addEventListener("change", applyFilters);
  reset.addEventListener("click", () => {
    state = readState(new URLSearchParams(), taxonomy);
    updateControls();
    applyFilters();
  });
  document.querySelector("#catalogue-controls").addEventListener("submit", (event) => {
    event.preventDefault();
    applyFilters();
  });
  for (const [button, shift] of [[previous, -1], [next, 1]]) {
    button.addEventListener("click", () => {
      page += shift;
      render();
      const heading = document.querySelector("#catalogue-results-heading");
      heading.tabIndex = -1;
      heading.focus();
    });
  }

  window.addEventListener("popstate", readLocation);
  window.addEventListener("hashchange", readLocation);
  readLocation();
}

start().catch(() => {
  statusLine.setAttribute("role", "alert");
  statusLine.textContent = "The catalogue could not load. Reload the page or use the CSV download.";
  const file = link("Catalogue CSV", "generated/downloads/records.csv");
  results.replaceChildren(file);
});
