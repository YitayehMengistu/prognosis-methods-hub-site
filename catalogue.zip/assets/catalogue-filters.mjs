export const facets = {
  resource_type: "Resource type",
  prediction_type: "Prediction type",
  research_stage: "Research stage",
  outcome_type: "Outcome type",
  modelling_approach: "Modelling approach",
  topics: "Topic",
  audience_level: "Audience level",
  authority_tier: "Authority tier",
  status: "Status",
  access: "Access",
};

const orders = new Set(["year", "tier", "citations"]);
const collator = new Intl.Collator("en", { sensitivity: "base" });

export function normalise(value) {
  return String(value).normalize("NFKD").replace(/\p{Diacritic}/gu, "").toLowerCase();
}

export function effectiveStatus(record) {
  const { curated, harvested } = record;
  if (harvested.is_retracted || harvested.update_notices.some((notice) => notice.type === "retraction")) {
    return "retracted";
  }
  return curated.status;
}

export function tagsFor(record, facet) {
  const tags = facet === "status" ? effectiveStatus(record) : record.curated[facet];
  return (Array.isArray(tags) ? tags : [tags]).map(String);
}

export function readState(params, taxonomy) {
  return {
    query: params.get("q") ?? "",
    order: orders.has(params.get("sort")) ? params.get("sort") : "year",
    current: params.get("current") === "1",
    open: params.get("open") === "1",
    core: params.get("core") === "1",
    filters: Object.fromEntries(Object.keys(facets).map((facet) => [
      facet, new Set(params.getAll(facet).filter((key) => Object.hasOwn(taxonomy[facet], key))),
    ])),
  };
}

export function writeState(state) {
  const params = new URLSearchParams();
  if (state.query.trim()) params.set("q", state.query.trim());
  if (state.order !== "year") params.set("sort", state.order);
  for (const toggle of ["current", "open", "core"]) {
    if (state[toggle]) params.set(toggle, "1");
  }
  for (const [facet, selected] of Object.entries(state.filters)) {
    for (const value of [...selected].sort()) params.append(facet, value);
  }
  return params;
}

export function prepareRecords(records, taxonomy) {
  return records.map((record) => {
    const { id, identifiers, harvested, curated } = record;
    const title = harvested.title ?? id;
    const labels = Object.keys(facets).flatMap((facet) => tagsFor(record, facet).map((key) => (
      taxonomy[facet][key]?.label ?? key
    )));
    const searchable = [
      id, title, ...harvested.authors, harvested.year, harvested.venue,
      identifiers.doi, identifiers.pmid, identifiers.isbn, curated.use_when,
      curated.why_it_matters, ...curated.key_points, ...labels,
    ].filter((value) => value !== null).join(" ");
    return { record, title, searchable: normalise(searchable) };
  });
}

export function selectRecords(prepared, state) {
  const terms = normalise(state.query).trim().split(/\s+/u).filter(Boolean);
  const filters = Object.entries(state.filters).filter(([, selected]) => selected.size > 0);
  return prepared.filter(({ record, searchable }) => {
    if (state.current && effectiveStatus(record) !== "current") return false;
    if (state.open && record.curated.access !== "open") return false;
    if (state.core && !record.curated.core) return false;
    return terms.every((term) => searchable.includes(term)) && filters.every(([facet, selected]) =>
      tagsFor(record, facet).some((tag) => selected.has(tag))
    );
  }).sort((first, second) => {
    const a = first.record;
    const b = second.record;
    let comparison = (b.harvested.year ?? -1) - (a.harvested.year ?? -1);
    if (state.order === "tier") comparison = a.curated.authority_tier - b.curated.authority_tier;
    if (state.order === "citations") {
      comparison = (b.harvested.cited_by_count ?? -1) - (a.harvested.cited_by_count ?? -1);
    }
    return comparison || collator.compare(first.title, second.title) || collator.compare(a.id, b.id);
  });
}
